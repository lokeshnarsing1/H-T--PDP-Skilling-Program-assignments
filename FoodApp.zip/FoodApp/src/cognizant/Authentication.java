package cognizant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Authentication {
	
	
	static final String db_url = "jdbc:mysql://localhost:3306/cognizant";
	static final String userName = "root";
	static final String password = "mysql";
	static final String driverClass = "com.mysql.jdbc.Driver";

	static final String login_query = "select * from login where email=? AND password=?";
	
	static final String signup_query = "insert into login (email,password)values (?,?)";
	
	static  String email = null;
	
	
	public boolean login(String email, String passs)
	{
		
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(login_query);){
				
				ps.setString(1, email);
				ps.setString(2, passs);
				
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {
					Authentication.email= rs.getString("email");
					System.out.println("Logged in successfully!");
					return false;
				}
				else{
					return true;
				}
		}catch(SQLException e) {
			e.printStackTrace();
			

	}
		
		
		return true;
	}
	
	
	
	public boolean signup(String email, String password)
	{
		
		
		
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(signup_query);){
				
				ps.setString(1, email);
				ps.setString(2, password);
				ps.executeUpdate();
				
			}catch(SQLException e) {
				System.out.println("Unable to add user");
				e.printStackTrace();
				return true;
			}
		
		
		return false;
		
	}

}
