package cognizant;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class Orders {
	
	
	static final String db_url = "jdbc:mysql://localhost:3306/cognizant";
	static final String userName = "root";
	static final String password = "mysql";
	static final String driverClass = "com.mysql.jdbc.Driver";

	static final String select_query = "select * from items";
	
	static final String select_cart_query = "select B.name,A.quantity  from cart A INNER JOIN items B on A.cart_id = B.id where A.email=?";
	
	static final String add_query = "insert into cart values (?,?,1)";
	
	static final String delete_query = "delete from cart where cart_id=?";
	
	static final String update_query = "update cart set quantity = ? where cart_id =? AND email = ? ";

	
	
	public List<Item> getItems()
	{
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(select_query);){
				
			
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					
					System.out.println(rs.getInt("id")+"."+rs.getString("name"));	
				}
		}catch(SQLException e) {
			e.printStackTrace();
	}
		
		return null;
	}
	
	public boolean addItem(int ItemId)
	{
		
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(add_query);){
				
			ps.setInt(1,ItemId );
			ps.setString(2, Authentication.email); 
			
				int rs=ps.executeUpdate();
				System.out.println("item added");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	public boolean removeItem(int item)
	{
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(delete_query);){
				
			    ps.setInt(1,item);
				ps.execute();
				
				System.out.println("item delete");
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	public boolean updateIem(int item,int quantity)
	{
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(update_query);){
				
			ps.setInt(1,quantity );
			ps.setInt(2,item);
			ps.setString(3,Authentication.email);
			
				int rs=ps.executeUpdate();
				System.out.println("item updated");
		}catch(SQLException e) {
			e.printStackTrace();
	}
		
		return false;
	}
	
	
	public void showCart()
	{
		try(Connection conn=DriverManager.getConnection(db_url,userName, password );
				PreparedStatement ps=conn.prepareStatement(select_cart_query);){
				
			    ps.setString(1,Authentication.email);
				ResultSet rs=ps.executeQuery();
				while(rs.next()) {
					
					System.out.println(rs.getString("name")+"    "+rs.getInt("quantity"));	
				}
		}catch(SQLException e) {
			e.printStackTrace();
	}
		
	
	}
	


}
