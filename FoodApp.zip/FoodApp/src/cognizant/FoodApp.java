package cognizant;

import java.util.Scanner;

public class FoodApp {
	
	static boolean notlogin = true;
	
	public static Authentication auth = new Authentication();
	
	public static Orders orders = new Orders();
	
	public static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		System.out.println("Welcome to food APP");
		
		
		while(notlogin)
		{
			System.out.println("1. Login \n2.Regiser");
			int opt = scanner.nextInt();
			
			if(opt ==1 )
			{
				System.out.println("Enter Email id");
				String email = scanner.next();
				
				System.out.println("Enter Password");
				String pass = scanner.next();
				
				notlogin = auth.login(email,pass);
			}
			if(opt ==2 )
			{
				
				System.out.println("Enter Email id");
				String email = scanner.next();
				
				System.out.println("Enter Password");
				String pass = scanner.next();
				
				notlogin = auth.signup(email,pass);
			}
			System.out.println("Try Again");
		}
		while(true)
		{
			
		
		System.out.println("Select Options !!! \n 1.Show All Items\n 2.add Items to cart \n 3.delete Items from cart\n 4.update Quantity in cart \n 5.show cart \n 6. Exit");
		int opt = scanner.nextInt();
		if(opt ==1 ) {
			
			orders.getItems();
		}
		
		if(opt ==2 ) {
			System.out.println("Enter Item Id ");
			int itemId = scanner.nextInt();
			orders.addItem(itemId);
			
		}
		
		if(opt ==3 ) {
			System.out.println("Enter Item Id ");
			int itemId = scanner.nextInt();
			orders.removeItem(itemId);
			
		}
		
		if(opt ==4 ) {
			System.out.println("Enter Item Id ");
			int itemId = scanner.nextInt();
			
			System.out.println("Enter Quantity");
			int quantity = scanner.nextInt();
			
			orders.updateIem(itemId, quantity);
			
		}
		
		if(opt ==6 ) {
			System.out.println("\n\n\n\n\n Thanks for Shopping !!!!");
			break;
			
		}
		if(opt ==5 ) {
			
			orders.showCart();
		}
		

		}
		
		
		
	}

}
